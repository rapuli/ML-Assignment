import numpy as np
from sigmoid import sigmoid

print('Hello Python')

X = np.array([[1,0,1,0],[1,0,1,1],[0,1,0,1]])
wh = np.array([[0.42,0.88,0.55],[0.10,0.73,0.68],[0.60,0.18,0.47],[0.92,0.11,0.52]])
wh_r = np.random.random((4,3))
bh = np.array([[0.46,0.72,0.08]])
bh_r = np.random.random((1,3))
wout = np.array([[0.30],[0.25],[0.23]])
wout_r = np.random.random((3,1))
bout = 0.69
y = np.array([[1],[1],[0]])
lr = 0.1



hidden_layer_input  = X.dot(wh) + bh

hiddenlayer_activations = sigmoid(hidden_layer_input )

output_layer_input = hiddenlayer_activations.dot(wout) + bout
output = sigmoid(output_layer_input)
E = y - output
Slope_output_layer = sigmoid(output,True)
Slope_hidden_layer = sigmoid(hiddenlayer_activations,True)
d_output = E * Slope_output_layer
Error_at_hidden_layer = d_output.dot(wout.T)
d_hiddenlayer = Error_at_hidden_layer * Slope_hidden_layer
wout = wout + hiddenlayer_activations.T.dot(d_output) * lr
wh = wh + X.T.dot(d_hiddenlayer) * lr



print('X::\n',X)
print('wh::\n',wh)
print('hidden_layer_input::\n',hidden_layer_input )
print('hiddenlayer_activations::\n',hiddenlayer_activations)
print('output::\n',output)
print('E::\n',E)
print('Slope_output_layer::\n',Slope_output_layer)
print('Slope_hidden_layer::\n',Slope_hidden_layer)
print('d_output::\n',d_output)
print('Error_at_hidden_layer::\n',Error_at_hidden_layer)
print('d_hiddenlayer::\n',d_hiddenlayer)
print('wout::\n',wout)
print('wh::\n',wh)
print(wh_r)
print(bh_r)
print(wout_r)

